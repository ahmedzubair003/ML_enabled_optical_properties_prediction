set terminal pdf enhanced size 8cm,12cm
set output "W15MoSe18.pdf"

set key font ",18"
set key outside



set ylabel "E-E_{F} (eV)"



Ef=0.5602

ymin=-3
ymax=3

set yrange [ymin:ymax]
set xrange [0:1.5774]
set xtics ("{/Symbol G}" 0.0000, "M" 0.5774, "K" 0.9104, "{/Symbol G}" 1.5774)

set arrow from 0.5774, ymin to 0.5774, ymax nohead
set arrow from 0.9104, ymin to 0.9104, ymax nohead




plot  "bands.out.gnu" u 1:($2-Ef) w l lt rgb "blue" notitle,\
      0 w l lt -1 dt 2 notitle

