mpirun --oversubscribe -np 24 '/home/dr_zubair/qe-6.8/bin/pw.x' < pw.scf.in > pw.scf.out

mpirun --oversubscribe -np 24 '/home/dr_zubair/qe-6.8/bin/pw.x' < pw.bands.in > pw.bands.out

mpirun --oversubscribe -np 24 '/home/dr_zubair/qe-6.8/bin/bands.x' < band.in > band.out



